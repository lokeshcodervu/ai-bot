# Core application package
